<html>
	<head>
	
		<title>DealMart|Men's</title>
		
	</head>
	
	<body>
		
		<header>
			<div style="background:#ccffff">
			
				&emsp;&emsp;<b><font color="#800000" size="10">DealMart.com</font></b>
				&emsp;&emsp;<img src="b.jpg" style="height:15px"/>
				<input type="text" style="height:20px; width:400px"/>
				<a href="#"><button>Search</button></a>
				&emsp;&emsp;&emsp;&emsp;
				<a href="#"><button>Sign In</button></a>&emsp;
				<a href="#"><button>Need Help</button></a>&emsp;
				<a href="#"><button>Cart</button></a>
				
			</div>
		</header>
		
		<nav>
			<div style="background:#0198D1; height:50px;">
				&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
				<input type="submit" value="Electronics" name="electronics" style="background:#0198D1; height:50px; color:white"/>
				&emsp;
				<input type="submit" value="Mens Fashion" name="mensfashion" style="background:#0198D1; height:50px; color:white"/>
				&emsp;
				<input type="submit" value="Womens Fashion" name="womensfashion" style="background:#0198D1; height:50px; color:white"/>
				&emsp;
				<input type="submit" value="Sports" name="sports" style="background:#0198D1; height:50px; color:white"/>		
			</div>
		</nav><br>
		
		<div align="center">
			<img src="hm.jpg" >
			<p><i><b>New Arrival</b></i></p>
			<h2>Mens Polo T-Shirt</h2>
			<p>Product Code: HERI35</p>
			<p><b>Bdt: 1750 Tk</b></p>
			<p><b>Availibilty:</b> In Stock</p>
			<p><b>Condition:</b> Band New</p>
			<p><b>Brand:</b> H&M</p>
			<p><b>Materials:</b> 99.1% Cotton and .9% Polyster</p>
			<label>Quantity:</label>
			<input type="text" value="1">
			<input type="button" value="Add to cart">
		</div>
		<section>
			<div>
				<h4>Product Description:</h4>
				<p>This T-Shirt will give you the day long comfortability. Its made of pure 99.1% Cotton and .9% Polyster, that will ensure the air passing perfectly into body. Its very easy to wash and iron. Four different colors are available: Red, Blue, Green, Sky Blue. From five differrent sizes you can choose your perfect size that will suit in your body perfectly. </p>
			</div>
			
		</section>
	
		
		<footer>
			<div style="background:#222222; height:50px;" align="center">
				<p><font color="white">&copy; Copyright | DealMart.com</font></p>
			</div>
		</footer>
		
		</body>
		
		
</html>