<html>
<head>
	<title>DealMart|Electronics</title>
	<meta charset=utf-8 />
 <style>
    div.container {
      display:inline-block;
    }

    p {
      text-align:center;
    }
  </style>
</head>
<body>

<header>
	<div style="background:#ccffff">
			
	&emsp;&emsp;<b><font color="#800000" size="10">DealMart.com</font></b>
	&emsp;&emsp;<img src="image/search.png" style="height:15px"/>
	<input type="text" style="height:20px; width:400px"/>
	<a href="#"><button>Search</button></a>
	&emsp;&emsp;&emsp;&emsp;
	<a href="#"><button>Sign In</button></a>&emsp;
	<a href="#"><button>Need Help</button></a>&emsp;
	<a href="#"><button>Cart</button></a>
	</div>
	</header>
		
	<nav>
	<div style="background:#0198D1; height:50px;">
	&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
	<button style="background:#0198D1; height:50px;"><font color="white">Electronics</font></button>
	&emsp;
	<button style="background:#0198D1; height:50px;"><font color="white">Fashion Item</font></button>
	&emsp;
	<button style="background:#0198D1; height:50px;"><font color="white">Sports</font></button>
				
	</div>
	</nav><br>


	<h1 align="left">Electronics</h1>
	<h2 align="center">DealMart Today's Deal</h2>

  <div class="container">
	<fieldset >
		<legend><b>Hot Deal</b></legend>
		<a href="details_ae.php">
		<img src="ae.jpg" height="250" width="200" />
		</a>
		<h4>Apple Combo</h4>
		<h3>35.5$ <strike>38.75$</strike></h3>
		<input type="button" value="Add to cart">
		</fieldset>
  </div>
  
  <div class="container">
	<fieldset >
		<legend><b>New Item</b></legend>
		<a href="details_be.php">
		<img src="be.png" height="250" width="200" />
		</a>
		<h4>Nikon Professional Camera</h4>
		<h3>25.5$ <strike>28.75$</strike></h3>
		<input type="button" value="Add to cart">
	</fieldset>
  </div>
  
  <div class="container">

	<fieldset >
		<legend><b>Exclusive Item</b></legend>
		<a href="details_ce.php">
		<img src="ce.jpg" height="250" width="200" />
		</a>
		<h4>Microsoft Surface Pro</h4>
		<h3>15.5$ <strike>18.75$</strike></h3>
		<input type="button" value="Add to cart">
	</fieldset>
   
  </div>
  
  <div class="container">
	<fieldset >
		<legend><b>Hot Deal</b></legend>
		<a href="details_de.php">
		<img src="de.jpg" height="250" width="200" />
		</a>
		<h4>4k Action Camera</h4>
		<h3>45.5$ <strike>58.75$</strike></h3>
		<input type="button" value="Add to cart">
	</fieldset>
    
  
  </div>
  
  <div class="container">
   <fieldset>
		<legend><b>Limited Item</b></legend>
		<a href="details_ee.php">
		<img src="ee.jpg" height="250" width="200" />
		</a>
		<h4>Kindle 10"</h4>
		<h3>35.5$ <strike>38.75$</strike></h3>
		<input type="button" value="Add to cart">
	</fieldset>
  </div>
  
	<h2 align ="center">Regular Products</h2>
	
  <div class="container">
    <fieldset>
		<a href="details_fe.php">
		<img src="fe.jpg" height="200" width="200" />
		</a>
		<h4>Samsung Earphone</h4>
		<h3>35.5$</h3>
		<input type="button" value="Add to cart">
	</fieldset>
  </div>
  
  <div class="container">
   <fieldset>
		<a href="details_ge.php">
		<img src="ge.jpg" height="200" width="200" />
		</a>
		<h4>Samsung Tab 10"</h4>
		<h3>32$</h3>
		<input type="button" value="Add to cart">
	</fieldset>
  </div>
  
  <div class="container">
  <fieldset>
		<a href="details_he.php">
		<img src="he.jpg" height="200" width="200" />
		</a>
		<h4>Apple Earbud</h4>
		<h3>15.5$</h3>
		<input type="button" value="Add to cart">
	</fieldset>
  </div>
  
  <div class="container">
    <fieldset>
		<a href="details_ie.php">
		<img src="ie.jpg" height="200" width="200" />
		</a>
		<h4>Iphone 7S</h4>
		<h3>18$</h3>
		<input type="button" value="Add to cart">
	</fieldset>
  </div>
  
  <div class="container">
   <fieldset>
		<a href="details_je.php">
		<img src="je.jpg" height="200" width="200" />
		</a>
		<h4>Apple Smartwatch</h4>
		<h3>95$</h3>
		<input type="button" value="Add to cart">
	</fieldset>
 
  </div>
  
		<footer>
			<div style="background:#222222; height:50px;" align="center">
				<p><font color="white">&copy; Copyright | DealMart.com</font></p>
			</div>
		</footer>

  
</div>
</body>
</html>